package com.example.test_searchkey;

import java.util.List;

public interface MakeSuggestion {
    void getSuggestion (List<Suggestion> suggestions) ;
}
